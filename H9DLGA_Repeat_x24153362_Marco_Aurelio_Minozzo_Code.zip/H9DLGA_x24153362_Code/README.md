H9DLGA Repeat Project - Code Package
Student: Marco Aurelio Minozzo
Student number: x24153362
Module: H9DLGA Deep Learning and Generative AI (Repeat)
National College of Ireland

Project
-------
Galaxy morphology classification on Galaxy10 DECaLS using a convolutional VAE
for generative class balancing and ResNet50 transfer learning (CRISP-DM).

Research question
-----------------
Given class imbalance in Galaxy10 DECaLS, do VAE-generated synthetic images
improve CNN morphological classification on minority classes without degrading
majority-class performance?

Package contents
----------------
src/                 Python modules (data, VAE, CNN, training, evaluation)
notebooks/           CRISP-DM walkthrough notebook
outputs/figures/     Evaluation figures used in the report
outputs/metrics/     Held-out test metrics (JSON)
requirements.txt     Python dependencies
run.sh               Helper script to launch the pipeline

Not included (size / external data)
-----------------------------------
- Galaxy10_DECals.h5 (~2.6 GB): downloaded by src.data.download_galaxy10()
  Docs: https://astronn.readthedocs.io/en/latest/galaxy10.html
- Trained .pt checkpoints (~187 MB): regenerate with the commands below

Setup
-----
python3 -m venv .venv
source .venv/bin/activate
pip install torch torchvision --index-url https://download.pytorch.org/whl/cpu
pip install -r requirements.txt

Run
---
python -m src.run_pipeline
python -m src.run_pipeline --skip-download --resume-vae
python -m src.run_pipeline --smoke --skip-download

Reported held-out results (seed 42, stratified 70/15/15)
-------------------------------------------------------
Real-only CNN:   accuracy 0.6708, macro-F1 0.6477
Real+VAE CNN:    accuracy 0.7151, macro-F1 0.6856

Author statement
----------------
This code package is submitted as part of the individual H9DLGA repeat assessment
by Marco Aurelio Minozzo (x24153362).
